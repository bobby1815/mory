package com.kh.mory.Model;

public class Setup_ReportList
{

}
