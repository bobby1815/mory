package com.kh.mory.Model;

public class Setup_Realation_ManagementDTO
{
	private String user_id,user_nic,profile_location,basic_addr;

	public String getProfile_location()
	{
		return profile_location;
	}

	public void setProfile_location(String profile_location)
	{
		this.profile_location = profile_location;
	}

	public String getBasic_addr()
	{
		return basic_addr;
	}

	public void setBasic_addr(String basic_addr)
	{
		this.basic_addr = basic_addr;
	}

	public String getUser_id()
	{
		return user_id;
	}

	public void setUser_id(String user_id)
	{
		this.user_id = user_id;
	}

	public String getUser_nic()
	{
		return user_nic;
	}

	public void setUser_nic(String user_nic)
	{
		this.user_nic = user_nic;
	}


}
