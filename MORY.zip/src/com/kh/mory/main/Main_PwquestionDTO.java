package com.kh.mory.main;

public class Main_PwquestionDTO
{
	private String pwqu_code, pwqu_name;

	// getter / setter 구성
	
	public String getPwqu_code()
	{
		return pwqu_code;
	}

	public void setPwqu_code(String pwqu_code)
	{
		this.pwqu_code = pwqu_code;
	}

	public String getPwqu_name()
	{
		return pwqu_name;
	}

	public void setPwqu_name(String pwqu_name)
	{
		this.pwqu_name = pwqu_name;
	}
	
	
}
