
    CKEDITOR.editorConfig = function( config ) {
        config.height = '600px'; //Editor 높이
    };
 
    CKEDITOR.config.allowedContent = true; //Editor 안에서 CSS사용 가능



