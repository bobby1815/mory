package com.kh.mory.Setup_DAO;

public class Setup_CustomerCenterDAO
{

}
