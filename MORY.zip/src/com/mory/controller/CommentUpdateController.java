/*==================================
   CommentUpdateController.java
   - ����� ���� ��Ʈ�ѷ� Ŭ����.
==================================*/

package com.mory.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.mory.diary.DiaryDTO;
import com.mory.idao.ICommentDAO;


public class CommentUpdateController implements Controller
{
   // DAO �������̽� �ڷ��� ��� ����
   private ICommentDAO dao;

   // setter ����
   public void setDao(ICommentDAO dao)
   {
      this.dao = dao;
   }

   @Override
   public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception
   {
	   request.setCharacterEncoding("UTF-8");

		ModelAndView modelAndView = new ModelAndView();

		String comment_cont = request.getParameter("cont");
		String comment_reg_dtm = request.getParameter("dtm");
		String user_id = request.getParameter("id");
		String write_seq=request.getParameter("write_seq");

		try
		{
			DiaryDTO diary = new DiaryDTO();
			
			diary.setComment_cont(comment_cont);
			diary.setComment_reg_dtm(comment_reg_dtm);
			diary.setUser_id(user_id);
			
			dao.commentUpdate(diary);
			modelAndView.setViewName("DiaryPost.do?write_seq="+write_seq);

		} catch (Exception e)
		{
			System.out.println(e.toString());
		}

		return modelAndView;
   }
   
   
   

}