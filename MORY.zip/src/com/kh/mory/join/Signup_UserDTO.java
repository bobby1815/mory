package com.kh.mory.join;

public class Signup_UserDTO
{
	private String user_id, gen_code, page_code, open_code, user_nic, user_pw
			,user_name, user_tel, user_birth, user_email, zipcode, basic_addr
			,detail_addr, loca_code, city_code, pwqu_code, pwqu_answ;
	
	private String gen_name, page_name, open_name, acc_state_name, loca_name, city_name;

	private int acc_state_code, acc_grade_code;

	// getter / setter 구성
	public String getPwqu_code()
	{
		return pwqu_code;
	}

	public void setPwqu_code(String pwqu_code)
	{
		this.pwqu_code = pwqu_code;
	}

	public String getPwqu_answ()
	{
		return pwqu_answ;
	}

	public void setPwqu_answ(String pwqu_answ)
	{
		this.pwqu_answ = pwqu_answ;
	}
	
	public String getUser_id()
	{
		return user_id;
	}

	public void setUser_id(String user_id)
	{
		this.user_id = user_id;
	}

	public String getGen_code()
	{
		return gen_code;
	}

	public void setGen_code(String gen_code)
	{
		this.gen_code = gen_code;
	}

	public String getPage_code()
	{
		return page_code;
	}

	public void setPage_code(String page_code)
	{
		this.page_code = page_code;
	}

	public String getOpen_code()
	{
		return open_code;
	}

	public void setOpen_code(String open_code)
	{
		this.open_code = open_code;
	}

	public String getUser_nic()
	{
		return user_nic;
	}

	public void setUser_nic(String user_nic)
	{
		this.user_nic = user_nic;
	}

	public String getUser_pw()
	{
		return user_pw;
	}

	public void setUser_pw(String user_pw)
	{
		this.user_pw = user_pw;
	}

	public String getUser_name()
	{
		return user_name;
	}

	public void setUser_name(String user_name)
	{
		this.user_name = user_name;
	}

	public String getUser_tel()
	{
		return user_tel;
	}

	public void setUser_tel(String user_tel)
	{
		this.user_tel = user_tel;
	}

	public String getUser_birth()
	{
		return user_birth;
	}

	public void setUser_birth(String user_birth)
	{
		this.user_birth = user_birth;
	}

	public String getUser_email()
	{
		return user_email;
	}

	public void setUser_email(String user_email)
	{
		this.user_email = user_email;
	}

	public String getZipcode()
	{
		return zipcode;
	}

	public void setZipcode(String zipcode)
	{
		this.zipcode = zipcode;
	}

	public String getBasic_addr()
	{
		return basic_addr;
	}

	public void setBasic_addr(String basic_addr)
	{
		this.basic_addr = basic_addr;
	}

	public String getDetail_addr()
	{
		return detail_addr;
	}

	public void setDetail_addr(String detail_addr)
	{
		this.detail_addr = detail_addr;
	}

	public String getLoca_code()
	{
		return loca_code;
	}

	public void setLoca_code(String loca_code)
	{
		this.loca_code = loca_code;
	}

	public String getCity_code()
	{
		return city_code;
	}

	public void setCity_code(String city_code)
	{
		this.city_code = city_code;
	}

	public String getGen_name()
	{
		return gen_name;
	}

	public void setGen_name(String gen_name)
	{
		this.gen_name = gen_name;
	}

	public String getPage_name()
	{
		return page_name;
	}

	public void setPage_name(String page_name)
	{
		this.page_name = page_name;
	}

	public String getOpen_name()
	{
		return open_name;
	}

	public void setOpen_name(String open_name)
	{
		this.open_name = open_name;
	}

	public String getAcc_state_name()
	{
		return acc_state_name;
	}

	public void setAcc_state_name(String acc_state_name)
	{
		this.acc_state_name = acc_state_name;
	}

	public String getLoca_name()
	{
		return loca_name;
	}

	public void setLoca_name(String loca_name)
	{
		this.loca_name = loca_name;
	}

	public String getCity_name()
	{
		return city_name;
	}

	public void setCity_name(String city_name)
	{
		this.city_name = city_name;
	}

	public int getAcc_state_code()
	{
		return acc_state_code;
	}

	public void setAcc_state_code(int acc_state_code)
	{
		this.acc_state_code = acc_state_code;
	}

	public int getAcc_grade_code()
	{
		return acc_grade_code;
	}

	public void setAcc_grade_code(int acc_grade_code)
	{
		this.acc_grade_code = acc_grade_code;
	}

	
}
