package com.mory.diary;


public class DiaryDTO 
{
	String  write_seq,write_user_id,write_cont,write_reg_dtm ;
	String  requ_seq ,  user_id , user_nic;
	String  requ_user_id,acce_user_id,mem_rel_code;
	String result_yn;
	String diary_seq,diary_name;
	String diary_type_code ,diary_post_title;
	String commentseq , comment_cont,comment_reg_dtm;
	String diary_requ_seq,reco_cont,reco_reg_dtm;
	String reco_seq;
	
	public String getWrite_seq()
	{
		return write_seq;
	}
	public String getUser_id()
	{
		return user_id;
	}
	public void setUser_id(String user_id)
	{
		this.user_id = user_id;
	}
	public String getUser_nic()
	{
		return user_nic;
	}
	public void setUser_nic(String user_nic)
	{
		this.user_nic = user_nic;
	}
	public String getRequ_user_id()
	{
		return requ_user_id;
	}
	public void setRequ_user_id(String requ_user_id)
	{
		this.requ_user_id = requ_user_id;
	}
	public String getAcce_user_id()
	{
		return acce_user_id;
	}
	public void setAcce_user_id(String acce_user_id)
	{
		this.acce_user_id = acce_user_id;
	}
	public String getMem_rel_code()
	{
		return mem_rel_code;
	}
	public void setMem_rel_code(String mem_rel_code)
	{
		this.mem_rel_code = mem_rel_code;
	}
	public String getResult_yn()
	{
		return result_yn;
	}
	public void setResult_yn(String result_yn)
	{
		this.result_yn = result_yn;
	}
	public String getDiary_seq()
	{
		return diary_seq;
	}
	public void setDiary_seq(String diary_seq)
	{
		this.diary_seq = diary_seq;
	}
	public String getDiary_name()
	{
		return diary_name;
	}
	public void setDiary_name(String diary_name)
	{
		this.diary_name = diary_name;
	}
	public String getDiary_type_code()
	{
		return diary_type_code;
	}
	public void setDiary_type_code(String diary_type_code)
	{
		this.diary_type_code = diary_type_code;
	}
	
	public String getCommentseq()
	{
		return commentseq;
	}
	public void setCommentseq(String commentseq)
	{
		this.commentseq = commentseq;
	}
	public String getComment_cont()
	{
		return comment_cont;
	}
	public void setComment_cont(String comment_cont)
	{
		this.comment_cont = comment_cont;
	}
	public String getComment_reg_dtm()
	{
		return comment_reg_dtm;
	}
	public void setComment_reg_dtm(String comment_reg_dtm)
	{
		this.comment_reg_dtm = comment_reg_dtm;
	}

	public String getDiary_requ_seq()
	{
		return diary_requ_seq;
	}
	public void setDiary_requ_seq(String diary_requ_seq)
	{
		this.diary_requ_seq = diary_requ_seq;
	}
	public String getReco_cont()
	{
		return reco_cont;
	}
	public void setReco_cont(String reco_cont)
	{
		this.reco_cont = reco_cont;
	}
	public String getReco_reg_dtm()
	{
		return reco_reg_dtm;
	}
	public void setReco_reg_dtm(String reco_reg_dtm)
	{
		this.reco_reg_dtm = reco_reg_dtm;
	}
	public void setWrite_seq(String write_seq)
	{
		this.write_seq = write_seq;
	}
	public String getRequ_seq()
	{
		return requ_seq;
	}
	public void setRequ_seq(String requ_seq)
	{
		this.requ_seq = requ_seq;
	}
	public String getWrite_user_id()
	{
		return write_user_id;
	}
	public void setWrite_user_id(String write_user_id)
	{
		this.write_user_id = write_user_id;
	}
	public String getWrite_cont()
	{
		return write_cont;
	}
	public void setWrite_cont(String write_cont)
	{
		this.write_cont = write_cont;
	}
	public String getWrite_reg_dtm()
	{
		return write_reg_dtm;
	}
	public void setWrite_reg_dtm(String write_reg_dtm)
	{
		this.write_reg_dtm = write_reg_dtm;
	}
	public String getDiary_post_title()
	{
		return diary_post_title;
	}
	public void setDiary_post_title(String diary_post_title)
	{
		this.diary_post_title = diary_post_title;
	}
	public String getReco_seq()
	{
		return reco_seq;
	}
	public void setReco_seq(String reco_seq)
	{
		this.reco_seq = reco_seq;
	}
	
}
