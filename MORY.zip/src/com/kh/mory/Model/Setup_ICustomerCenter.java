package com.kh.mory.Model;

public interface Setup_ICustomerCenter
{

}
